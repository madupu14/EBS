package com.alekhya.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alekhya.dto.FundTransferRequest;
import com.alekhya.entity.Account;
import com.alekhya.repository.AccountRepository;

@Service
public class FundTransferServiceImpl implements FundTransferService {

    private final AccountRepository accountRepository;

    @Autowired
    public FundTransferServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public boolean transferFunds(FundTransferRequest request) {
        Account sourceAccount = accountRepository.findByAccountNumber(request.getSourceAccountNumber());
        Account destinationAccount = accountRepository.findByAccountNumber(request.getDestinationAccountNumber());

        if (sourceAccount == null || destinationAccount == null) {
            return false; // Accounts not found
        }

        // Check if source account has sufficient balance
        if (sourceAccount.getAvailableBalance().compareTo(request.getAmount()) < 0) {
            return false; // Insufficient balance
        }

        // Update account balances
        sourceAccount.setAvailableBalance(sourceAccount.getAvailableBalance().subtract(request.getAmount()));
        destinationAccount.setAvailableBalance(destinationAccount.getAvailableBalance().add(request.getAmount()));

        accountRepository.save(sourceAccount);
        accountRepository.save(destinationAccount);

        return true; // Transfer successful
    }
}
