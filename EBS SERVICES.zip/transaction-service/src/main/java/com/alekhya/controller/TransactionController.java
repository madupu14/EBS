package com.alekhya.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.alekhya.entity.Transaction;
import com.alekhya.service.TransactionService;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<?> getTransactionsForAccount(@PathVariable String accountNumber) {
        List<Transaction> transactions = transactionService.getTransactionsForAccount(accountNumber);
        if (transactions.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No transactions found for account number: " + accountNumber);
        }
        return ResponseEntity.ok(transactions);
    }
}

